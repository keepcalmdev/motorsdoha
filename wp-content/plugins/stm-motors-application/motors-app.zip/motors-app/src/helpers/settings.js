const liveUri = 'http://stylemixthemes.com/';

export default {
    BASE_URL: liveUri,
    REST_URL: liveUri + 'wp-json/stm-mra/v1'
}