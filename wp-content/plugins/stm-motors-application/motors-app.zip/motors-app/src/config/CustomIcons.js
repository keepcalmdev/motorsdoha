import {createIconSetFromIcoMoon} from 'react-native-vector-icons';
import icoMoonConfig from '../config/CustomIcons.json';
export default createIconSetFromIcoMoon(icoMoonConfig, 'stm-service-default', 'motorsappicon.ttf');