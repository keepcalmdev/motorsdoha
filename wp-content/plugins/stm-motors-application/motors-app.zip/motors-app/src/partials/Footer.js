import React from 'react';
import {View, Text} from 'react-native';

class Footer extends React.Component {
    render() {

    }
}

export default Footer;